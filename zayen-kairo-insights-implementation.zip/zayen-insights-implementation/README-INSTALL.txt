# Zayen Kairo — Insights implementation

## Files included
- `blog.html` — replaces the current Notes/Blog placeholder and becomes the Insights listing page.
- `css/insights.css` — page-specific styles; does not replace `css/style.css`.
- `js/insights-data.js` — article catalogue and metadata.
- `js/insights.js` — live search, topic filters, featured story and load-more behavior.
- `insights/cybersecurity-fundamentals.html` — first complete individual article page with SEO metadata, Open Graph tags, BlogPosting JSON-LD and table of contents.

## Install
Copy these files/folders into the root of your existing website, merging folders:
- Replace existing `blog.html`.
- Add `css/insights.css`.
- Add `js/insights-data.js` and `js/insights.js`.
- Add the `insights/` folder.

Do not replace `css/style.css` or `js/main.js`. The listing and article pages continue to use the shared header/footer inserted by your existing `main.js`.

## Important follow-up edits
1. In `js/main.js`, change the visible navigation label from `Journal` (or `Notes`) to `Insights` while keeping its href as `blog.html`.
2. Replace `https://YOUR-DOMAIN` in the canonical and Open Graph URL fields in `blog.html` and `insights/cybersecurity-fundamentals.html` with your final live website domain. Do not leave the placeholder in production.
3. The article catalogue currently contains one published article. Other cards are marked `published: false` and intentionally show as in-development; create their pages before changing them to `true`.
4. Add real, locally optimized images if you prefer not to use the current Unsplash-hosted image URLs. Keep meaningful alt text.
5. Ensure your site's `robots.txt` and XML sitemap include the new article URL after deployment.

## Add another article
Add an object to `js/insights-data.js` with:
- `title`, `category`, `excerpt`, `date`, `readTime`
- `image`, `imageAlt`, `url`, `keywords`
- `published: true` only after its standalone HTML file exists.
Use one of the existing category names exactly: `Cybersecurity`, `Artificial Intelligence`, `Linux`, `Windows`, `Networking`, `Cloud`, `Programming`.

## Design and behavior
- Uses the existing cream/forest-green/gold palette and Playfair Display/DM Sans fonts.
- Search matches article title, category, excerpt and keywords.
- Topic filters work without reloading the page.
- Featured article is hidden while a search or category filter is active.
- Cards reveal with subtle motion; respects `prefers-reduced-motion`.
- Layout adapts for desktop, tablet and mobile.

## Editorial/SEO note
The included cybersecurity guide is an educational overview, not a substitute for organization-specific security advice. Review technical content, dates and metadata before publishing. Avoid claiming guaranteed search rankings.
