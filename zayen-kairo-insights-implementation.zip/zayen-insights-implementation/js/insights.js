document.addEventListener("DOMContentLoaded", () => {
  const grid = document.getElementById("insights-grid");
  if (!grid || !Array.isArray(window.insightsArticles)) return;

  const articles = window.insightsArticles;
  const searchInput = document.getElementById("insights-search-input");
  const filters = document.getElementById("insights-filters");
  const count = document.getElementById("insights-count");
  const featured = document.getElementById("featured-insight");
  const empty = document.getElementById("insights-empty");
  const loadMore = document.getElementById("insights-load-more");
  const reset = document.getElementById("insights-reset");
  const pageSize = 6;
  let activeCategory = "All";
  let visibleCount = pageSize;

  const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);

  const formatDate = value => {
    const date = new Date(`${value}T12:00:00`);
    return Number.isNaN(date.getTime()) ? "" : new Intl.DateTimeFormat("en-US", {
      month: "short", day: "numeric", year: "numeric"
    }).format(date);
  };

  const searchable = article => [
    article.title, article.category, article.excerpt, article.keywords
  ].join(" ").toLowerCase();

  const matchingArticles = () => {
    const query = searchInput.value.trim().toLowerCase();
    return articles.filter(article => {
      const categoryMatch = activeCategory === "All" || article.category === activeCategory;
      return categoryMatch && (!query || searchable(article).includes(query));
    });
  };

  const metaHTML = article => `
    <div class="insight-meta">
      <span class="insight-category">${escapeHTML(article.category)}</span>
      ${article.published ? `<span>${formatDate(article.date)}</span><span>${escapeHTML(article.readTime)}</span>` : `<span class="insight-status">IN DEVELOPMENT</span>`}
    </div>`;

  const cardHTML = (article, index) => {
    const content = `
      <a class="insight-card-image" ${article.published ? `href="${escapeHTML(article.url)}"` : `href="#${'latest-insights'}" aria-label="Article coming soon"`}>
        <img src="${escapeHTML(article.image)}" alt="${escapeHTML(article.imageAlt)}" loading="lazy" decoding="async">
      </a>
      <div class="insight-card-body">
        ${metaHTML(article)}
        <h3>${article.published ? `<a href="${escapeHTML(article.url)}">${escapeHTML(article.title)}</a>` : escapeHTML(article.title)}</h3>
        <p>${escapeHTML(article.excerpt)}</p>
        ${article.published ? `<a class="insight-read-link" href="${escapeHTML(article.url)}">READ ARTICLE <span aria-hidden="true">↗</span></a>` : `<span class="insight-status">ARTICLE COMING SOON</span>`}
      </div>`;
    return `<article class="insight-card ${article.published ? "" : "is-coming-soon"}" style="--card-index:${index}">${content}</article>`;
  };

  const renderFeatured = list => {
    const item = list.find(article => article.featured && article.published);
    if (!item) {
      featured.hidden = true;
      featured.innerHTML = "";
      return;
    }
    featured.hidden = false;
    featured.innerHTML = `
      <a class="featured-image" href="${escapeHTML(item.url)}">
        <img src="${escapeHTML(item.image)}" alt="${escapeHTML(item.imageAlt)}" loading="lazy" decoding="async">
      </a>
      <div class="featured-copy">
        <p class="eyebrow">EDITOR'S PICK</p>
        ${metaHTML(item)}
        <h3>${escapeHTML(item.title)}</h3>
        <p>${escapeHTML(item.excerpt)}</p>
        <a class="insight-read-link" href="${escapeHTML(item.url)}">READ THE FEATURE <span aria-hidden="true">↗</span></a>
      </div>`;
  };

  const render = () => {
    const matches = matchingArticles();
    const publishedMatches = matches.filter(article => article.published);
    renderFeatured(matches);
    const visible = matches.slice(0, visibleCount);
    grid.innerHTML = visible.map(cardHTML).join("");
    count.textContent = `${matches.length} ${matches.length === 1 ? "article" : "articles"} and guides`;
    empty.hidden = matches.length !== 0;
    grid.hidden = matches.length === 0;
    loadMore.hidden = matches.length <= visibleCount;
    if (searchInput.value.trim() || activeCategory !== "All") {
      featured.hidden = true;
    }
  };

  filters.addEventListener("click", event => {
    const button = event.target.closest("button[data-category]");
    if (!button) return;
    activeCategory = button.dataset.category;
    filters.querySelectorAll(".insight-filter").forEach(item => {
      const selected = item === button;
      item.classList.toggle("is-active", selected);
      item.setAttribute("aria-pressed", String(selected));
    });
    visibleCount = pageSize;
    render();
  });

  searchInput.addEventListener("input", () => {
    visibleCount = pageSize;
    render();
  });

  loadMore.addEventListener("click", () => {
    visibleCount += pageSize;
    render();
  });

  reset.addEventListener("click", () => {
    searchInput.value = "";
    activeCategory = "All";
    visibleCount = pageSize;
    filters.querySelectorAll(".insight-filter").forEach(item => {
      const selected = item.dataset.category === "All";
      item.classList.toggle("is-active", selected);
      item.setAttribute("aria-pressed", String(selected));
    });
    render();
  });

  render();

  const revealItems = document.querySelectorAll(".insights-page .reveal");
  if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach(item => observer.observe(item));
  } else {
    revealItems.forEach(item => item.classList.add("is-visible"));
  }
});
